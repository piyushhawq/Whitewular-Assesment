import React from "react";
import Navbar from "./component/navbar";
import Location from "./component/location";
import Footer from "./component/footer";
import Card from "./component/card";

import "./App.css";

export default function App() {
  return (
    <>
    
      <Navbar />
      <Location />
      <div className="container">
      <Card 
        image="http://res.cloudinary.com/whitewular-com/image/authenticated/s--s8TiL3JN--/v1666771919/xnqscssvdcefp9mijyka.png"
        heading="Thinkwala Traders"
        text="Household Care & Cleaning | Organic & Ayurveda | Women Clothing, Tailoring & Accessories | Tourism & Hospitality | Tech Development & IT Solutions | Teaching & Education | Sports, Fitness and Trainer | Salon Services | Repair & Maintenance | Rental & Leasing | Pet Supplies & Services | Musical Instruments | Men Clothing, Tailoring & Accessories | Medical Supplies & Services | Industrial Supplies & Services | Handmade & Handicraft | Grocery & Gourmet Foods | Games & Toys | Freelancers & Contractors | Finance & Legal Services | Filming & Shooting | Events & Parties | Electronics & Electricals | Decor & Designing | Deals & Offers | Cosmetic & Personal Care | Building Materails & Construction Services | Books & Stationery | Agriculture & Farming | Accessories | Automobiles Parts & Spares | Baby Products | Baggage & Luggage | Gifting & Hampers" 
      />
    </div>
      <Footer />
  
    </>
  );
}
