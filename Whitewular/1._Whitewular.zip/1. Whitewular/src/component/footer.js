import React from "react";
import "./footer.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faTwitter,
  faInstagram,
  faYoutube,
  faFacebook,
  faLinkedin,
} from "@fortawesome/free-brands-svg-icons";
import { faAngleRight } from "@fortawesome/free-solid-svg-icons";

export default function Footer() {
  const sections = [
    {
      title: "COMPANY",
      items: ["About Us", "Safe life with us"],
    },
    {
      title: "My Account",
      items: ["Create Account", "Account Login"],
    },
    {
      title: "Work With Us",
      items: ["Become a Supplier/Service Proovider"],
    },
    {
      title: "Policies",
      items: [
        "Privacy Policy",
        "Cancellation, Return, Refund and Payment Policy",
        "User Agreement or Terms of Use",
        "Virtual Money Policy",
        "Terms And Conditions",
      ],
    },
    {
      title: "Help Center",
      items: ["File A Complaint", "Locate Collection Center"],
    },
  ];

  return (
    <footer>
      <div className="AboutUs row">
        {sections.map((section, index) => (
          <div key={index} className="footer-section">
            <h3>{section.title}</h3>
            <ul>
              {section.items.map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="socialContact row">
        <div className="social-media">
          <h1>WhiteWular Social</h1>
          <div className="social-icons">
            <FontAwesomeIcon
              className="icons"
              icon={faTwitter}
              color="#1da1f2"
              size="2x"
            />
            <FontAwesomeIcon
              className="icons"
              icon={faInstagram}
              color="#e1306c"
              size="2x"
            />
            <FontAwesomeIcon
              className="icons"
              icon={faYoutube}
              size="2x"
              color="#ff0000"
            />
            <FontAwesomeIcon
              className="icons"
              icon={faFacebook}
              size="2x"
              color="#3b5998"
            />
            <FontAwesomeIcon
              className="icons"
              icon={faLinkedin}
              size="2x"
              color="#0077B5"
            />
          </div>
        </div>
        <div className="email">
          <h1>JOIN THE NEWSLETTER</h1>
          <p>Get the latest updates from the whitewular</p>
          <div className="email-input">
            <input type="email" placeholder="Enter your email" />
            <button>
              <FontAwesomeIcon icon={faAngleRight} size="1x" />
            </button>
          </div>
        </div>
      </div>
      <div>
        <span className="copyright">
          Copyright© 2018 whitewular.com. All rights reserved
        </span>
      </div>
    </footer>
  );
}
