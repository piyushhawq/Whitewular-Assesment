import React from 'react';

const Card = ({image, heading, text}) => {
  return (
    <div className="card">
                <h1>{heading}</h1>
      <img src={image} alt="Card Image" />
      <div className="card-content">
        <h3>{heading}</h3>
        <p>{text}</p>
      </div>
    </div>
  );
};

export default Card;
