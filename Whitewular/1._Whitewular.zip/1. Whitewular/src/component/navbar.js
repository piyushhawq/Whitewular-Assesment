import React from "react";
import { useState, useEffect } from "react";
import "./navbar.css";
import { library } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { fas } from "@fortawesome/free-solid-svg-icons";
import { fab } from "@fortawesome/free-brands-svg-icons";
import Dropdown from "react-bootstrap/Dropdown";

library.add(fas, fab);

export default function Navbar() {
  const options = [
    "Recharge",
    "Bill Payments",
    "Cosmetic & Personal Care",
    "Finance & Legal Services",
    "Repair & Maintenance",
    "Tech Development & IT Solutions",
    "Electronics & Electrials",
    "Events & Parties",
    "Accessories",
    "Deals & Offers",
    "Baby Products",
    "Baggage & Luggage",
    "Moms and Maternity",
    "Grocery & Gourmet Foods",
    "Organic & Ayurveda",
    "Pet Supplies & Services",
    "Women Clothing, Tailoring & Accessories",
    "Household Care & Cleaning",
    "Medical Supplies & Services",
    "Decor & Designing",
    "Freelancers & Contractors",
    "string",
    "Gifting & Hampers",
  ];
  const [isOpen, setIsOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(null);
  function handleClick() {
    setIsOpen(!isOpen);
  }

  useEffect(() => {
    function handleClickOutside(event) {
      if (event.target.closest(".dropdown") === null) {
        setIsOpen(false);
      }
    }
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [isOpen]);
  return (
    <nav>
      <img
        alt="white-icon"
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZUUzr-VDjfNKF5xPK1pqcgcAXhd8YRuxvUgoI4-3-aA&s"
      ></img>
      <div className="dropdown">
        <div onClick={handleClick} className="dropdown-selected">
          Categories<span className="triangle"></span>
        </div>
        {isOpen && (
          <div className="dropdown-options">
            {options.map((option, i) => (
              <div
                key={option}
                className="dropdown-option"
                onMouseEnter={() => setIsHovered(i)}
              >
                {option}
                {isHovered === i && <div className="additional-options"></div>}
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="searchcontainer">
        <form>
          <input type="text" placeholder="Search..." />
          <button type="submit">
            <FontAwesomeIcon icon={["fas", "search"]} />
          </button>
        </form>
      </div>
      <span className="locality">What's in your locality?</span>
      <div className="betadiv">
        <h6>BETA Version</h6>
        <div className="navbar-icons">
          <div>
            <FontAwesomeIcon className="nav-icons" icon={["fas", "gift"]} />
            <FontAwesomeIcon className="nav-icons" icon={["fas", "heart"]} />
            <FontAwesomeIcon
              className="nav-icons"
              icon={["fas", "mobile-alt"]}
            />
            <FontAwesomeIcon
              className="nav-icons"
              icon={["fas", "shopping-cart"]}
            />
          </div>
          <div>
            <Dropdown className="kishan">
              <Dropdown.Toggle id="dropdown-basic" className="custom-color">
                <FontAwesomeIcon icon={["fas", "user"]} />
              </Dropdown.Toggle>

              <Dropdown.Menu className="usermenu">
                <Dropdown.Item href="#/action-1">
                  <FontAwesomeIcon
                    className="profile-icons"
                    icon="fa-solid fa-user"
                  />
                  Action
                </Dropdown.Item>
                <Dropdown.Item href="#/action-2">
                  <FontAwesomeIcon
                    className="profile-icons"
                    icon="fa-solid fa-headset"
                  />
                  Another action
                </Dropdown.Item>
                <Dropdown.Item href="#/action-3">
                  <FontAwesomeIcon
                    className="profile-icons"
                    icon="fa-solid fa-right-from-bracket"
                  />
                  Something else
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
      </div>
    </nav>
  );
}
