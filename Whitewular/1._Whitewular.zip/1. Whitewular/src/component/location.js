import React from "react";
import { useState } from "react";
import Select from "react-select";
import "./location.css";

const options = [
  { value: "option1", label: "Option 1" },
  { value: "option2", label: "Option 2" },
  { value: "option3", label: "Option 3" },
];

export default function Location() {
  const [pincode, setPincode] = useState("");
  const [location, setLocation] = useState("");

  const [selectedOptions, setSelectedOptions] = useState([]);

  function handlePincodeChange(e) {
    setPincode(e.target.value);
    if (pincode.length === 6) {
      fetch(
        `https://api.opencagedata.com/geocode/v1/json?q=${pincode}&category=${selectedOptions}&key=1d3f34c1ddd542518e835a88bdc709c6&countrycode=IN`
      )
        .then((response) => response.json())
        .then((data) => {
          if (data && data.results && data.results[0]) {
            const location = data.results[0].formatted;
            setLocation(location);
          } else {
            setLocation("Location not found");
          }
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      setLocation("Enter 6-digit pincode");
    }
  }
  function handleLocationChange(event) {
    setLocation(event.target.value);
  }

  return (
    <>
      <div className="location">
        <div>
          <input
            className="pincode-input"
            placeholder="Pincode"
            type="text"
            value={pincode}
            onChange={handlePincodeChange}
          />
          <br />
        </div>
        <div>
          <input
            placeholder="City,State"
            className="auto-location"
            type="text"
            value={location}
            onChange={handleLocationChange}
            readOnly
          />
        </div>
        <Select
          isMulti
          options={options}
          value={selectedOptions}
          onChange={setSelectedOptions}
        />
      </div>
      <div>
        {pincode && location && selectedOptions && (
          <h1>
            {pincode},{location}, Category: {selectedOptions}
          </h1>
        )}
      </div>
    </>
  );
}
